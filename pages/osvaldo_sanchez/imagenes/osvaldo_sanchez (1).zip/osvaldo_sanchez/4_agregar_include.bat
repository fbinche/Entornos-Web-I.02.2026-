@echo off
set GITCONFIG=%USERPROFILE%\.gitconfig
echo.>> "%GITCONFIG%"
echo [includeIf "gitdir:C:/Repositorios/osvaldo_sanchez/"]>> "%GITCONFIG%"
echo     path = C:/Repositorios/.gitconfig-osvaldo_sanchez>> "%GITCONFIG%"
pause
