@echo off
set RAMA=osvaldo_sanchez
set DESTINO=C:\Repositorios
set CARPETA=%DESTINO%\%RAMA%
set ARCHIVO=.gitconfig-%RAMA%

if not exist "%CARPETA%" mkdir "%CARPETA%"
if not exist "%ARCHIVO%" (
    echo No se encontro %ARCHIVO%
    pause
    exit
)

move /Y "%ARCHIVO%" "%DESTINO%\%ARCHIVO%"
pause
