@echo off
cd /d %~dp0
if not exist key_osvaldo_sanchez.pub (
    echo Ejecuta primero 1_key_osvaldo_sanchez.bat
    pause
    exit
)
type key_osvaldo_sanchez.pub
type key_osvaldo_sanchez.pub | clip
pause
