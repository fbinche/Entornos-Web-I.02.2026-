@echo off
cd /d %~dp0
ssh-keygen -t ed25519 -C "at73167929@idat.pe" -f key_osvaldo_sanchez -N ""
pause
