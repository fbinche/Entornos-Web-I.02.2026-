@echo off
ssh -T github-osvaldo_sanchez
pause
